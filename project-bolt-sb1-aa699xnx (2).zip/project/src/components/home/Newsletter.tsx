import React, { useState } from 'react';
import { useToast } from '../ui/Toaster';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const { showToast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      showToast('Please enter your email address', 'error');
      return;
    }
    
    // In a real app, you would handle the subscription here
    showToast('Thank you for subscribing to our newsletter!', 'success');
    setEmail('');
  };

  return (
    <section className="py-20 bg-indigo-600">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Join Our Newsletter
          </h2>
          <p className="text-indigo-100 mb-8 text-lg">
            Subscribe to our newsletter and be the first to know about new products, exclusive offers, and upcoming sales.
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              placeholder="Your email address"
              className="input flex-grow text-base py-3 px-4"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button 
              type="submit" 
              className="bg-white text-indigo-600 hover:bg-indigo-50 font-medium py-3 px-6 rounded-md transition-colors duration-300"
            >
              Subscribe
            </button>
          </form>

          <p className="text-indigo-200 text-sm mt-4">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </div>
      </div>

      {/* Wave decoration */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden">
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          viewBox="0 0 1200 120" 
          preserveAspectRatio="none"
          className="relative block w-full h-12"
        >
          <path 
            d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" 
            className="fill-white"
          ></path>
        </svg>
      </div>
    </section>
  );
};

export default Newsletter;