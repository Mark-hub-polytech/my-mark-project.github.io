import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-indigo-50 to-white">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Discover Quality Products at <span className="text-indigo-600">Markstore</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0">
              Shop the latest trends with confidence. Free shipping on orders over $50 and hassle-free returns.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link to="/products" className="btn-primary py-3 px-8 text-base">
                Shop Now
              </Link>
              <Link to="/products?featured=true" className="btn-secondary py-3 px-8 text-base flex items-center justify-center">
                Featured Products
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl transform transition-transform duration-500 hover:scale-[1.02]">
              <img 
                src="https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Markstore featured products" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-6">
                <span className="inline-block bg-indigo-600 text-white px-3 py-1 rounded-full text-sm font-medium mb-3">
                  New Collection
                </span>
                <h3 className="text-white text-2xl font-bold">Summer Essentials</h3>
              </div>
            </div>
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-amber-500 rounded-full flex items-center justify-center text-white font-bold text-xl transform rotate-12">
              20% OFF
            </div>
          </div>
        </div>
      </div>
      
      {/* Floating features */}
      <div className="container mt-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-md flex items-center transform transition-transform duration-300 hover:-translate-y-1">
            <div className="bg-indigo-100 p-3 rounded-full mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Free Shipping</h3>
              <p className="text-gray-600 text-sm">On orders over $50</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md flex items-center transform transition-transform duration-300 hover:-translate-y-1">
            <div className="bg-indigo-100 p-3 rounded-full mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-lg">30-Day Returns</h3>
              <p className="text-gray-600 text-sm">Hassle-free returns</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-md flex items-center transform transition-transform duration-300 hover:-translate-y-1">
            <div className="bg-indigo-100 p-3 rounded-full mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-lg">Secure Payments</h3>
              <p className="text-gray-600 text-sm">Safe & encrypted</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;