import { Product } from '../types';

// Sample product data
const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Bluetooth Headphones',
    description: 'Premium noise-cancelling wireless headphones with long battery life and superior sound quality.',
    price: 149.99,
    originalPrice: 199.99,
    discount: 25,
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Electronics',
    inStock: true,
    rating: 4.8,
    reviews: 256,
    featured: true,
    createdAt: '2023-06-15T10:00:00Z'
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    description: 'Track your fitness goals with this advanced smartwatch featuring heart rate monitoring, GPS, and personalized coaching.',
    price: 89.99,
    originalPrice: 119.99,
    discount: 25,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Electronics',
    inStock: true,
    rating: 4.5,
    reviews: 187,
    featured: true,
    createdAt: '2023-07-20T10:00:00Z'
  },
  {
    id: '3',
    name: 'Premium Cotton T-Shirt',
    description: 'Ultra-soft, breathable cotton t-shirt with a modern fit, perfect for everyday wear.',
    price: 24.99,
    originalPrice: 29.99,
    discount: 17,
    image: 'https://images.pexels.com/photos/4066293/pexels-photo-4066293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Clothing',
    inStock: true,
    rating: 4.3,
    reviews: 152,
    featured: false,
    createdAt: '2023-05-10T10:00:00Z'
  },
  {
    id: '4',
    name: 'Ergonomic Office Chair',
    description: 'Comfortable ergonomic office chair with adjustable height, lumbar support, and breathable mesh back for long working hours.',
    price: 199.99,
    originalPrice: 249.99,
    discount: 20,
    image: 'https://images.pexels.com/photos/1957478/pexels-photo-1957478.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Home',
    inStock: true,
    rating: 4.7,
    reviews: 108,
    featured: true,
    createdAt: '2023-03-25T10:00:00Z'
  },
  {
    id: '5',
    name: 'Stainless Steel Water Bottle',
    description: 'Eco-friendly, vacuum-insulated water bottle that keeps drinks cold for 24 hours or hot for 12 hours.',
    price: 29.99,
    originalPrice: 34.99,
    discount: 14,
    image: 'https://images.pexels.com/photos/4210850/pexels-photo-4210850.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Accessories',
    inStock: true,
    rating: 4.6,
    reviews: 89,
    featured: false,
    createdAt: '2023-08-05T10:00:00Z'
  },
  {
    id: '6',
    name: 'Wireless Charging Pad',
    description: 'Fast wireless charging pad compatible with all Qi-enabled devices, featuring a sleek, minimalist design.',
    price: 39.99,
    originalPrice: 49.99,
    discount: 20,
    image: 'https://images.pexels.com/photos/12276390/pexels-photo-12276390.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Electronics',
    inStock: true,
    rating: 4.4,
    reviews: 76,
    featured: false,
    createdAt: '2023-07-15T10:00:00Z'
  },
  {
    id: '7',
    name: 'Leather Wallet',
    description: 'Genuine leather wallet with multiple card slots, ID window, and RFID blocking technology.',
    price: 49.99,
    originalPrice: 59.99,
    discount: 17,
    image: 'https://images.pexels.com/photos/4452526/pexels-photo-4452526.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Accessories',
    inStock: true,
    rating: 4.5,
    reviews: 64,
    featured: false,
    createdAt: '2023-06-20T10:00:00Z'
  },
  {
    id: '8',
    name: 'Smart Home Speaker',
    description: 'Voice-controlled smart speaker with premium sound quality and integrated virtual assistant.',
    price: 129.99,
    originalPrice: 149.99,
    discount: 13,
    image: 'https://images.pexels.com/photos/4388193/pexels-photo-4388193.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'Electronics',
    inStock: false,
    rating: 4.7,
    reviews: 95,
    featured: true,
    createdAt: '2023-05-05T10:00:00Z'
  }
];

export const getAllProducts = (): Product[] => {
  return products;
};

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category.toLowerCase() === category.toLowerCase());
};

export const featuredProducts = products.filter(product => product.featured);