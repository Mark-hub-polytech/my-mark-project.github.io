import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, SlidersHorizontal, Grid, List, ChevronDown, Star } from 'lucide-react';
import ProductCard from '../components/product/ProductCard';
import { getAllProducts } from '../data/products';
import { Product } from '../types';

const ProductsPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortOption, setSortOption] = useState('featured');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedRatings, setSelectedRatings] = useState<number[]>([]);

  // Get query parameters
  const categoryParam = searchParams.get('category');
  const searchQuery = searchParams.get('search');
  
  useEffect(() => {
    // Fetch products
    const fetchedProducts = getAllProducts();
    setProducts(fetchedProducts);
    
    // Initialize filters from URL params if any
    if (categoryParam) {
      setSelectedCategories([categoryParam]);
    }
    
    // Apply initial filters
    applyFilters(fetchedProducts);
  }, [categoryParam]);
  
  const applyFilters = (productsList: Product[] = products) => {
    let filtered = [...productsList];
    
    // Apply search query filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query)
      );
    }
    
    // Apply category filter
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(product => 
        selectedCategories.includes(product.category.toLowerCase())
      );
    }
    
    // Apply rating filter
    if (selectedRatings.length > 0) {
      filtered = filtered.filter(product => 
        selectedRatings.includes(Math.floor(product.rating))
      );
    }
    
    // Apply price range filter
    filtered = filtered.filter(product => 
      product.price >= priceRange[0] && product.price <= priceRange[1]
    );
    
    // Apply sorting
    switch (sortOption) {
      case 'priceAsc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'priceDesc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'popular':
        filtered.sort((a, b) => b.reviews - a.reviews);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      default: // 'featured'
        filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }
    
    setFilteredProducts(filtered);
  };
  
  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };
  
  const toggleRating = (rating: number) => {
    if (selectedRatings.includes(rating)) {
      setSelectedRatings(selectedRatings.filter(r => r !== rating));
    } else {
      setSelectedRatings([...selectedRatings, rating]);
    }
  };
  
  useEffect(() => {
    applyFilters();
  }, [selectedCategories, selectedRatings, priceRange, sortOption, searchQuery]);
  
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const newValue = parseInt(e.target.value);
    const newRange = [...priceRange] as [number, number];
    newRange[index] = newValue;
    setPriceRange(newRange);
  };

  const clearAllFilters = () => {
    setSelectedCategories([]);
    setSelectedRatings([]);
    setPriceRange([0, 1000]);
    setSortOption('featured');
  };
  
  return (
    <div className="container py-8 mt-16">
      <h1 className="text-3xl font-bold mb-8">
        {categoryParam 
          ? `${categoryParam.charAt(0).toUpperCase() + categoryParam.slice(1)} Products`
          : searchQuery
          ? `Search Results for "${searchQuery}"`
          : 'All Products'
        }
      </h1>
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters for Mobile */}
        <div className="lg:hidden flex justify-between items-center mb-4">
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="btn-secondary py-2 px-4 flex items-center"
          >
            <Filter size={16} className="mr-2" />
            Filters
          </button>
          
          <div className="flex items-center gap-4">
            <select 
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="input py-2"
            >
              <option value="featured">Featured</option>
              <option value="priceAsc">Price: Low to High</option>
              <option value="priceDesc">Price: High to Low</option>
              <option value="newest">Newest</option>
              <option value="popular">Most Popular</option>
              <option value="rating">Highest Rated</option>
            </select>
            
            <div className="flex items-center border rounded-md overflow-hidden">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 ${viewMode === 'grid' ? 'bg-indigo-100 text-indigo-600' : 'bg-white text-gray-600'}`}
              >
                <Grid size={18} />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 ${viewMode === 'list' ? 'bg-indigo-100 text-indigo-600' : 'bg-white text-gray-600'}`}
              >
                <List size={18} />
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile Filters */}
        {isFilterOpen && (
          <div className="lg:hidden bg-white p-4 rounded-lg shadow-md mb-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Filters</h3>
              <button onClick={clearAllFilters} className="text-indigo-600 text-sm">Clear All</button>
            </div>
            
            {/* Mobile Category Filter */}
            <div className="mb-4">
              <h4 className="font-medium mb-2">Categories</h4>
              <div className="space-y-2">
                {['electronics', 'clothing', 'home', 'accessories'].map(category => (
                  <label key={category} className="flex items-center">
                    <input 
                      type="checkbox"
                      checked={selectedCategories.includes(category)}
                      onChange={() => toggleCategory(category)}
                      className="mr-2"
                    />
                    <span className="capitalize">{category}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Mobile Price Range Filter */}
            <div className="mb-4">
              <h4 className="font-medium mb-2">Price Range</h4>
              <div className="flex items-center justify-between mb-2">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
              <input 
                type="range"
                min="0"
                max="1000"
                value={priceRange[0]}
                onChange={(e) => handlePriceChange(e, 0)}
                className="w-full mb-2"
              />
              <input 
                type="range"
                min="0"
                max="1000"
                value={priceRange[1]}
                onChange={(e) => handlePriceChange(e, 1)}
                className="w-full"
              />
            </div>
            
            {/* Mobile Rating Filter */}
            <div>
              <h4 className="font-medium mb-2">Rating</h4>
              <div className="space-y-2">
                {[4, 3, 2, 1].map(rating => (
                  <label key={rating} className="flex items-center">
                    <input 
                      type="checkbox"
                      checked={selectedRatings.includes(rating)}
                      onChange={() => toggleRating(rating)}
                      className="mr-2"
                    />
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          size={16} 
                          className={i < rating ? "text-amber-400 fill-amber-400" : "text-gray-300"} 
                        />
                      ))}
                      <span className="ml-1 text-sm">& Up</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}
        
        {/* Desktop Filters */}
        <div className="hidden lg:block w-64 flex-shrink-0">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 sticky top-24">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-medium flex items-center">
                <SlidersHorizontal size={16} className="mr-2" />
                Filters
              </h3>
              <button onClick={clearAllFilters} className="text-indigo-600 text-sm hover:underline">
                Clear All
              </button>
            </div>
            
            {/* Category Filter */}
            <div className="mb-6">
              <h4 className="font-medium mb-3 flex items-center justify-between">
                Categories
                <ChevronDown size={16} />
              </h4>
              <div className="space-y-2">
                {['electronics', 'clothing', 'home', 'accessories'].map(category => (
                  <label key={category} className="flex items-center cursor-pointer">
                    <input 
                      type="checkbox"
                      checked={selectedCategories.includes(category)}
                      onChange={() => toggleCategory(category)}
                      className="mr-2 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="capitalize text-gray-700">{category}</span>
                  </label>
                ))}
              </div>
            </div>
            
            {/* Price Range Filter */}
            <div className="mb-6">
              <h4 className="font-medium mb-3 flex items-center justify-between">
                Price Range
                <ChevronDown size={16} />
              </h4>
              <div className="flex items-center justify-between mb-2 text-sm">
                <span className="text-gray-600">${priceRange[0]}</span>
                <span className="text-gray-600">${priceRange[1]}</span>
              </div>
              <div className="relative">
                <input 
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange(e, 0)}
                  className="w-full mb-2 accent-indigo-600"
                />
                <input 
                  type="range"
                  min="0"
                  max="1000"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange(e, 1)}
                  className="w-full accent-indigo-600"
                />
              </div>
            </div>
            
            {/* Rating Filter */}
            <div>
              <h4 className="font-medium mb-3 flex items-center justify-between">
                Rating
                <ChevronDown size={16} />
              </h4>
              <div className="space-y-2">
                {[4, 3, 2, 1].map(rating => (
                  <label key={rating} className="flex items-center cursor-pointer">
                    <input 
                      type="checkbox"
                      checked={selectedRatings.includes(rating)}
                      onChange={() => toggleRating(rating)}
                      className="mr-2 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          size={14} 
                          className={i < rating ? "text-amber-400 fill-amber-400" : "text-gray-300"} 
                        />
                      ))}
                      <span className="ml-1 text-sm text-gray-700">& Up</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Product List */}
        <div className="flex-grow">
          {/* Desktop Sort and View Options */}
          <div className="hidden lg:flex justify-between items-center mb-6">
            <p className="text-gray-600">
              Showing <span className="font-medium">{filteredProducts.length}</span> products
            </p>
            
            <div className="flex items-center gap-4">
              <label className="flex items-center">
                <span className="mr-2 text-gray-700">Sort by:</span>
                <select 
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="input py-1 px-3"
                >
                  <option value="featured">Featured</option>
                  <option value="priceAsc">Price: Low to High</option>
                  <option value="priceDesc">Price: High to Low</option>
                  <option value="newest">Newest</option>
                  <option value="popular">Most Popular</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </label>
              
              <div className="flex items-center border rounded-md overflow-hidden">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${viewMode === 'grid' ? 'bg-indigo-100 text-indigo-600' : 'bg-white text-gray-600'}`}
                  aria-label="Grid view"
                >
                  <Grid size={18} />
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={`p-2 ${viewMode === 'list' ? 'bg-indigo-100 text-indigo-600' : 'bg-white text-gray-600'}`}
                  aria-label="List view"
                >
                  <List size={18} />
                </button>
              </div>
            </div>
          </div>
          
          {/* No Results */}
          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your search or filter criteria</p>
              <button 
                onClick={clearAllFilters}
                className="btn-primary py-2 px-4"
              >
                Clear All Filters
              </button>
            </div>
          )}
          
          {/* Products Grid/List */}
          <div className={
            viewMode === 'grid' 
              ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" 
              : "space-y-6"
          }>
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;