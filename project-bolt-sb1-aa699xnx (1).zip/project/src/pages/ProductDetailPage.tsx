import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Truck, ShieldCheck, ArrowLeft, Heart, Share2, Plus, Minus } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { getProductById } from '../data/products';
import { Product } from '../types';
import { useToast } from '../components/ui/Toaster';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const { addToCart } = useCart();
  const { showToast } = useToast();
  
  useEffect(() => {
    if (id) {
      const fetchedProduct = getProductById(id);
      if (fetchedProduct) {
        setProduct(fetchedProduct);
      }
    }
  }, [id]);

  if (!product) {
    return (
      <div className="container py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Link to="/products" className="btn-primary py-2 px-4">
          Back to Products
        </Link>
      </div>
    );
  }
  
  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
    showToast(`${product.name} added to cart`, 'success');
  };

  // Dummy array of product images
  const productImages = [
    product.image,
    'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/704555/pexels-photo-704555.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/1667088/pexels-photo-1667088.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  ];
  
  return (
    <div className="container py-8 mt-16">
      <div className="flex items-center mb-6">
        <Link to="/products" className="text-gray-600 hover:text-indigo-600 flex items-center">
          <ArrowLeft size={16} className="mr-1" />
          Back to Products
        </Link>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Product Images */}
        <div>
          <div className="relative mb-4 aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={productImages[selectedImage]}
              alt={product.name}
              className="h-full w-full object-cover object-center"
            />
            {product.discount > 0 && (
              <div className="absolute top-4 left-4 bg-red-500 text-white text-sm font-bold px-2 py-1 rounded">
                {product.discount}% OFF
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-4 gap-4">
            {productImages.map((image, index) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`aspect-square rounded-md overflow-hidden border-2 ${
                  selectedImage === index 
                    ? 'border-indigo-600' 
                    : 'border-transparent hover:border-gray-300'
                }`}
              >
                <img
                  src={image}
                  alt={`${product.name} view ${index + 1}`}
                  className="h-full w-full object-cover object-center"
                />
              </button>
            ))}
          </div>
        </div>
        
        {/* Product Details */}
        <div>
          <div className="mb-6">
            <span className="inline-block text-sm font-medium text-indigo-600 mb-2 uppercase tracking-wider">
              {product.category}
            </span>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex mr-2">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    size={18} 
                    className={i < product.rating ? "text-amber-400 fill-amber-400" : "text-gray-300"} 
                  />
                ))}
              </div>
              <span className="text-gray-600 text-sm">{product.reviews} reviews</span>
            </div>
            
            <div className="flex items-baseline mb-4">
              <span className="text-2xl font-bold text-gray-900">${product.price.toFixed(2)}</span>
              
              {product.originalPrice && (
                <span className="text-lg text-gray-500 line-through ml-2">
                  ${product.originalPrice.toFixed(2)}
                </span>
              )}
              
              {product.discount > 0 && (
                <span className="ml-2 text-green-600 font-medium">
                  Save ${(product.originalPrice! - product.price).toFixed(2)}
                </span>
              )}
            </div>
            
            <p className="text-gray-700 mb-6">{product.description}</p>
            
            {/* Stock Status */}
            <div className="mb-6">
              {product.inStock ? (
                <span className="text-green-600 font-medium flex items-center">
                  <svg className="w-4 h-4 mr-1\" fill="currentColor\" viewBox="0 0 20 20">
                    <path fillRule="evenodd\" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z\" clipRule="evenodd" />
                  </svg>
                  In Stock
                </span>
              ) : (
                <span className="text-red-600 font-medium flex items-center">
                  <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                  Out of Stock
                </span>
              )}
            </div>
            
            {/* Quantity Selector */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quantity
              </label>
              <div className="flex items-center">
                <button 
                  onClick={decrementQuantity}
                  disabled={quantity <= 1}
                  className="p-2 border border-gray-300 rounded-l-md bg-gray-50 text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                >
                  <Minus size={16} />
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="p-2 w-16 text-center border-y border-gray-300 text-gray-900"
                />
                <button 
                  onClick={incrementQuantity}
                  className="p-2 border border-gray-300 rounded-r-md bg-gray-50 text-gray-600 hover:bg-gray-100"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button 
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="btn-primary py-3 px-8 flex-grow flex items-center justify-center"
              >
                <ShoppingCart size={18} className="mr-2" />
                Add to Cart
              </button>
              
              <button className="btn-secondary py-3 flex items-center justify-center">
                <Heart size={18} className="mr-2" />
                Wishlist
              </button>
              
              <button className="btn-secondary py-3 px-3 sm:px-0">
                <Share2 size={18} />
              </button>
            </div>
            
            {/* Product Features */}
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex items-start">
                <Truck size={20} className="text-indigo-600 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-medium text-gray-900">Free Shipping</h4>
                  <p className="text-sm text-gray-600">Free standard shipping on orders over $50</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <ShieldCheck size={20} className="text-indigo-600 mr-3 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-medium text-gray-900">30-Day Returns</h4>
                  <p className="text-sm text-gray-600">Hassle-free returns if you're not satisfied</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Product Details Tabs */}
      <div className="mt-16">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            <button className="border-b-2 border-indigo-600 py-4 px-1 text-sm font-medium text-indigo-600 whitespace-nowrap mr-8">
              Product Details
            </button>
            <button className="border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 whitespace-nowrap hover:text-gray-700 hover:border-gray-300 mr-8">
              Specifications
            </button>
            <button className="border-b-2 border-transparent py-4 px-1 text-sm font-medium text-gray-500 whitespace-nowrap hover:text-gray-700 hover:border-gray-300">
              Reviews ({product.reviews})
            </button>
          </nav>
        </div>
        
        <div className="py-8">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Product Description</h3>
          <div className="prose max-w-none text-gray-700">
            <p>
              {product.description}
            </p>
            <p className="mt-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Sed euismod, nisl vel ultricies 
              lacinia, nisl nisl aliquam nisl, vitae aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies
              lacinia, nisl nisl aliquam nisl, vitae aliquam nisl nisl sit amet nisl.
            </p>
            <ul className="mt-4 list-disc pl-5 space-y-2">
              <li>Premium quality materials for durability</li>
              <li>Ergonomic design for comfort</li>
              <li>Versatile functionality for various uses</li>
              <li>Easy to clean and maintain</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;